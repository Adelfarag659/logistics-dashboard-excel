import LogisticsDashboard from './LogisticsDashboard';
export default function App() { return <LogisticsDashboard />; }